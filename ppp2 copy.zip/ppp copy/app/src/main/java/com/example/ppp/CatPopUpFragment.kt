package com.example.ppp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.fragment.app.DialogFragment

class CatPopUpFragment : DialogFragment() { //Cat stands for 'category'

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NO_TITLE, R.style.dialog); //so we can set up the rounded theme + animation
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_cat_pop_up, container, false)
    }

    var catArray: Array<String> = emptyArray()
    //this creates actions on what happens when you actually click the buttons
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val btnEditText = view.findViewById<Button>(R.id.btn_cat_buttonEditText)
        val editTextCategory = view.findViewById<EditText>(R.id.et_cat_name) //stores the edited text? would want to keep this in mind for project revisions
        val imgClose : ImageView = view.findViewById(R.id.exp_imgClose)

        btnEditText.setOnClickListener{
            val valueCat = editTextCategory.text.toString() //actually takes in the user input and converts to a string
            catArray += valueCat

            /* length_long displays text for about 3.5 secs */
           if(valueCat.isEmpty()) {
               Toast.makeText(context, "Please fill in the expense input first", Toast.LENGTH_LONG)
                   .show()
           }
            else {
                val connectedString = valueCat
                Toast.makeText(context, connectedString, Toast.LENGTH_LONG).show()   //displays converted user input
                dismiss()
            }
        }

        //closes dialog fragment
        imgClose.setOnClickListener{
            dismiss()
        }
    }
}