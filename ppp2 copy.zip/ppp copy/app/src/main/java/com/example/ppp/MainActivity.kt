package com.example.ppp

import android.app.Fragment
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.DialogFragment
import com.example.ppp.R.id.btn_addBudget
import com.example.ppp.R.id.btn_addCategory


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //add expense button
        val expBtn : Button = findViewById(R.id.btn_addExpenses)
        expBtn.setOnClickListener{
            val showPopUpExpenses = ExpPopUpFragment()
            showPopUpExpenses.show(supportFragmentManager, "showPopUpExpenses")
        }

        //add budget button
        val budBtn : Button = findViewById(btn_addBudget)
        budBtn.setOnClickListener{
            val showPopUpBudget = BudPopUpFragment()
            showPopUpBudget.show(supportFragmentManager, "showPopUpBudget")
        }

        //add category button
        val catBtn : Button = findViewById(btn_addCategory)
        catBtn.setOnClickListener{
            val showPopUpCategory = CatPopUpFragment()
            showPopUpCategory.show(supportFragmentManager, "showPopUpCategory")
        }
    }
}

//MainFragment.kt
// package com.example.ppp
//
//import android.os.Bundle
//import android.view.LayoutInflater
//import android.view.View
//import android.view.ViewGroup
//import android.widget.Button
//import androidx.appcompat.app.AppCompatActivity
//import androidx.fragment.app.Fragment
//import com.example.ppp.R.layout
//
////there may be a problem here bc tutorial starts out with a MainFragment that has imports and such
////manually wrote this in, may interfere with mainActivity? not sure
////everything here is arbitrary????
//class MainFragment : Fragment() {
//    override fun onCreateView(
//        inflater: LayoutInflater, container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View? {
//        return inflater.inflate(layout.activity_main, container,false)
//    }
//}